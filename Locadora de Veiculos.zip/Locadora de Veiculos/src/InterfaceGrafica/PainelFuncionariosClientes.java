package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Execoes.ContaNaoExisteExeception;
import Execoes.CpfException;
import Execoes.ExisteItensLocadosExeception;
import Execoes.ExisteMultasExeception;
import Execoes.NullExeception;
import Negocio.Entidades.Cliente;
import Negocio.Entidades.Locacao;
import Negocio.Entidades.Multas;
import Negocio.Fachada.Fachada;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PainelFuncionariosClientes extends JFrame {

	private JPanel contentPane;
	private JTextField cpf;
	private JTextField nome;
	private JPasswordField senha;
	private static PainelFuncionariosClientes instance;
	private JTextField telefone;
    public static PainelFuncionariosClientes getInstance() {
		if (PainelFuncionariosClientes.instance == null) {
			return PainelFuncionariosClientes.instance = new PainelFuncionariosClientes();
		}
		return PainelFuncionariosClientes.instance;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelFuncionariosClientes frame = new PainelFuncionariosClientes();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PainelFuncionariosClientes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton CadastroCliente = new JButton("Cadastrar Cliente");
		CadastroCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.getInstance().CadastrarCliente(nome.getText(), cpf.getText(), new String(senha.getPassword()) , telefone.getText(), cpf.getText(), cpf.getText());
				} catch (CpfException | NullExeception e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
				}
				Fachada.getInstance().SalvarTodosArquivos();
				GUI.cliente =null;
				GUI.locacao = null;
				GUI.multa = null;
				try {
					if(Fachada.getInstance().VerificarContaCliente(cpf.getText(), new String(senha.getPassword())) == true) {
						JFrame frame = new JFrame("Cadastrado!");
						JOptionPane.showMessageDialog(frame, "Cliente cadastrado com sucesso");
					}
				} catch (ContaNaoExisteExeception e1) {
					JFrame frameErro = new JFrame("Erro!");
					JOptionPane.showMessageDialog(frameErro, "Erro ao cadastrar cliente", "", JOptionPane.ERROR_MESSAGE);
					e1.printStackTrace();
				}
			}
		});
		CadastroCliente.setBounds(10, 87, 142, 23);
		contentPane.add(CadastroCliente);
		
		JButton remocaocliente = new JButton("Remover Cliente");
		remocaocliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.getInstance().RemoverCliente(cpf.getText());
				} catch (CpfException | NullExeception | ExisteItensLocadosExeception | ExisteMultasExeception e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
					e1.printStackTrace();
				}
				Fachada.getInstance().SalvarTodosArquivos();
			}
		});
		remocaocliente.setBounds(10, 121, 142, 23);
		contentPane.add(remocaocliente);
		
		JButton devolucao = new JButton("Devolu\u00E7\u00E3o de Veiculo");
		devolucao.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
					PainelFuncionarioDevolucao.getInstance().setVisible(true);
					dispose();
			}
		});
		devolucao.setBounds(10, 178, 142, 23);
		contentPane.add(devolucao);
		
		JLabel lblPainelDosFuncionarios = new JLabel("Painel dos Funcionarios Para Clientes");
		lblPainelDosFuncionarios.setBounds(124, 11, 191, 14);
		contentPane.add(lblPainelDosFuncionarios);
		
		cpf = new JTextField();
		cpf.setBounds(281, 69, 127, 20);
		contentPane.add(cpf);
		cpf.setColumns(10);
		
		nome = new JTextField();
		nome.setBounds(281, 100, 127, 20);
		contentPane.add(nome);
		nome.setColumns(10);
		
		senha = new JPasswordField();
		senha.setBounds(281, 131, 127, 20);
		contentPane.add(senha);
		senha.setColumns(10);
		
		JLabel lbCpf = new JLabel("CPF :");
		lbCpf.setBounds(222, 72, 46, 14);
		contentPane.add(lbCpf);
		
		JLabel lblNome = new JLabel("Nome :");
		lblNome.setBounds(222, 103, 46, 14);
		contentPane.add(lblNome);
		
		JLabel lblSenha = new JLabel("Senha :");
		lblSenha.setBounds(222, 134, 46, 14);
		contentPane.add(lblSenha);
		
		JLabel lblRemooCpf = new JLabel("Remo\u00E7\u00E3o -> Cpf");
		lblRemooCpf.setBounds(10, 46, 95, 14);
		contentPane.add(lblRemooCpf);
		
		JLabel lblCadastroTodos = new JLabel("Cadastro -> Todos os Campos");
		lblCadastroTodos.setBounds(10, 62, 165, 14);
		contentPane.add(lblCadastroTodos);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(10, 236, 181, 14);
		contentPane.add(label);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PainelFuncionarios.getInstance().setVisible(true);
				dispose();
			}
		});
		button.setBounds(378, 7, 46, 23);
		contentPane.add(button);
		
		telefone = new JTextField();
		telefone.setBounds(281, 162, 86, 20);
		contentPane.add(telefone);
		telefone.setColumns(10);
		
		JLabel lblTelefone = new JLabel("Telefone :");
		lblTelefone.setBounds(222, 165, 49, 14);
		contentPane.add(lblTelefone);
	}

}
