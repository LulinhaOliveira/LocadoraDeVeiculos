package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Dados.ClientesRepositorio;
import Execoes.ContaNaoExisteExeception;

import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

import InterfaceGrafica.GUI;
import Negocio.Fachada.Fachada;


public class JanelaCliente extends JFrame {
	
	private JPanel PainelCliente;

	private JTextField loginCliente;
	private JPasswordField senhaCliente;

	
    static JanelaCliente instance;
    public static JanelaCliente getInstance() {
		if (JanelaCliente.instance == null) {
			return JanelaCliente.instance = new JanelaCliente();
		}
		return JanelaCliente.instance;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaCliente frame = new JanelaCliente();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaCliente() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		PainelCliente = new JPanel();
		PainelCliente.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(PainelCliente);
		PainelCliente.setLayout(null);
		
		JLabel lblBemVindoAo = new JLabel("Login Para Clientes");
		lblBemVindoAo.setBounds(167, 11, 180, 14);
		PainelCliente.add(lblBemVindoAo);
		
		JLabel lblLogincpf = new JLabel("Login (CPF)");
		lblLogincpf.setBounds(21, 66, 63, 14);
		PainelCliente.add(lblLogincpf);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(21, 91, 46, 14);
		PainelCliente.add(lblSenha);
		
		loginCliente = new JTextField();
		loginCliente.setBounds(94, 63, 86, 20);
		PainelCliente.add(loginCliente);
		loginCliente.setColumns(10);
		
		senhaCliente = new JPasswordField();
		senhaCliente.setBounds(94, 88, 86, 20);
		PainelCliente.add(senhaCliente);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			try {
				if(Fachada.getInstance().VerificarContaCliente(loginCliente.getText(), new String(senhaCliente.getPassword())) == true) {
					GUI.cpf = loginCliente.getText();
					PainelClientes.getInstance().setVisible(true);
					dispose();
				}
			} catch (ContaNaoExisteExeception e1) {
				JOptionPane.showConfirmDialog(null, e1.toString());
			}
			}
		});

		btnEntrar.setBounds(94, 121, 89, 23);
		PainelCliente.add(btnEntrar);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(10, 236, 181, 14);
		PainelCliente.add(label);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {			
	            GUI.getInstance().setVisible(true);
				dispose(); 
			}
		});
		button.setBounds(378, 7, 46, 23);
		PainelCliente.add(button);
		
	}
}
