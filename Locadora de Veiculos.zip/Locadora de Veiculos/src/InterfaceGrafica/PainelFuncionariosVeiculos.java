package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Execoes.AnoValidarExeception;
import Execoes.ContaNaoExisteExeception;
import Execoes.NullExeception;
import Execoes.PlacaExisteExeception;
import Execoes.PlacaNaoExiste;
import Execoes.PlacaValidacaoExeception;
import Execoes.PrecoExeception;
import Execoes.VeiculoAlugadoExeception;
import Negocio.Entidades.Veiculo;
import Negocio.Fachada.Fachada;

import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

public class PainelFuncionariosVeiculos extends JFrame {


	private JPanel Marca;
	private JTextField placar;
	private JTextField Cor;
	private JTextField Preco;
	private JTextField Modelo;
	private JTextField marca;
	private JTextField Ano;
	private static PainelFuncionariosVeiculos instance;
    public static PainelFuncionariosVeiculos getInstance() {
		if (PainelFuncionariosVeiculos.instance == null) {
			return PainelFuncionariosVeiculos.instance = new PainelFuncionariosVeiculos();
		}
		return PainelFuncionariosVeiculos.instance;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelFuncionariosVeiculos frame = new PainelFuncionariosVeiculos();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PainelFuncionariosVeiculos() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		Marca = new JPanel();
		Marca.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(Marca);
		Marca.setLayout(null);
		
		JButton btnCadastrarVeiculo = new JButton("Cadastrar Veiculo");
		btnCadastrarVeiculo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			    try {
					Fachada.getInstance().CadastrarVeiculo(placar.getText(),marca.getText(),Modelo.getText(),Cor.getText(),Integer.parseInt(Ano.getText()),Double.parseDouble(Preco.getText()));
				    if(Fachada.getInstance().getVc().VerificarPlacaExiste(placar.getText()) == 0) {
				    	JOptionPane.showMessageDialog(null,"Veiculo Cadastrado Com Sucesso","Mensagem", JOptionPane.PLAIN_MESSAGE);	    
				    }else {
				    	JOptionPane.showMessageDialog(null,"Erro no Cadastro","Mensagem", JOptionPane.ERROR_MESSAGE);
				    }

			    } catch (PlacaValidacaoExeception | NullExeception | AnoValidarExeception | PlacaExisteExeception e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
				}    	    
			    Fachada.getInstance().SalvarTodosArquivos();    
			    placar.setText("");
			    marca.setText("");
			    Modelo.setText("");
			    Cor.setText("");
			    Ano.setText("");
			    Preco.setText("");
			}
		});
		btnCadastrarVeiculo.setBounds(10, 105, 160, 23);
		Marca.add(btnCadastrarVeiculo);
		
		JButton btnRemoverVeiculo = new JButton("Remover Veiculo");
		btnRemoverVeiculo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			//	try {
				
				Fachada.getInstance().getVc().getVeiculo().Remover(placar.getText());
				
		//		} catch (PlacaValidacaoExeception | NullExeception e1) {
		//			JOptionPane.showMessageDialog(null, e1.toString(), "Error", JOptionPane.PLAIN_MESSAGE);
		//			e1.printStackTrace();
		//		} catch (PlacaNaoExiste e1) {
		//			JOptionPane.showMessageDialog(null, e1.toString(), "Error", JOptionPane.PLAIN_MESSAGE);
		//			e1.printStackTrace();
	//			}
				Fachada.getInstance().SalvarTodosArquivos();
			    placar.setText("");
			    marca.setText("");
			    Modelo.setText("");
			    Cor.setText("");
			    Ano.setText("");
			    Preco.setText("");
			}
		});
		btnRemoverVeiculo.setBounds(10, 139, 160, 23);
		Marca.add(btnRemoverVeiculo);
		
		JButton btnAtualizarCorDo = new JButton("Atualizar Cor Do Veiculo");
		btnAtualizarCorDo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.getInstance().getVc().AtualizaCor(placar.getText(), Cor.getText());
				} catch (PlacaValidacaoExeception | NullExeception e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
					e1.printStackTrace();
				}
				Fachada.getInstance().SalvarTodosArquivos();
			}
		});
		btnAtualizarCorDo.setBounds(10, 178, 160, 23);
		Marca.add(btnAtualizarCorDo);
		
		JButton btnAtulizarPreoDo = new JButton("Atulizar Pre\u00E7o do Veiculo");
		btnAtulizarPreoDo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.getInstance().getVc().AtualizaPreco(placar.getText(),Double.parseDouble(Preco.getText()));
				} catch (NumberFormatException | PlacaValidacaoExeception | NullExeception | PrecoExeception
						| VeiculoAlugadoExeception e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
					e1.printStackTrace();
				}
				Fachada.getInstance().SalvarTodosArquivos();
			}
		});
		btnAtulizarPreoDo.setBounds(10, 212, 160, 23);
		Marca.add(btnAtulizarPreoDo);
		
		JLabel lblPainelDosFuncionarios = new JLabel("Painel dos Funcionarios Para Veiculos");
		lblPainelDosFuncionarios.setBounds(139, 11, 208, 14);
		Marca.add(lblPainelDosFuncionarios);
		
		placar = new JTextField();
		placar.setBounds(275, 57, 104, 20);
		Marca.add(placar);
		placar.setColumns(10);
		
		JLabel lblPlaca = new JLabel("Placa      :");
		lblPlaca.setBounds(228, 60, 64, 14);
		Marca.add(lblPlaca);
		
		Cor = new JTextField();
		Cor.setBounds(275, 179, 104, 20);
		Marca.add(Cor);
		Cor.setColumns(10);
		
		JLabel lblCor = new JLabel("Cor       :");
		lblCor.setBounds(228, 182, 46, 14);
		Marca.add(lblCor);
		
		Preco = new JTextField();
		Preco.setBounds(275, 213, 104, 20);
		Marca.add(Preco);
		Preco.setColumns(10);
		
		JLabel lblPreo = new JLabel("Pre\u00E7o    :");
		lblPreo.setBounds(228, 216, 46, 14);
		Marca.add(lblPreo);
		
		JLabel lblRemooPlaca = new JLabel("Remo\u00E7\u00E3o -> Placa");
		lblRemooPlaca.setBounds(10, 45, 98, 14);
		Marca.add(lblRemooPlaca);
		
		JLabel lblNovaCor = new JLabel("Nova Cor -> Placa & Cor");
		lblNovaCor.setBounds(10, 57, 124, 14);
		Marca.add(lblNovaCor);
		
		JLabel lblNovoPreo = new JLabel("Novo Pre\u00E7o -> Placa & Pre\u00E7o");
		lblNovoPreo.setBounds(10, 68, 138, 14);
		Marca.add(lblNovoPreo);
		
		JLabel lblCadastroTodos = new JLabel("Cadastro -> Todos os Campos");
		lblCadastroTodos.setBounds(10, 80, 160, 14);
		Marca.add(lblCadastroTodos);
		
		Modelo = new JTextField();
		Modelo.setBounds(275, 93, 104, 20);
		Marca.add(Modelo);
		Modelo.setColumns(10);
		
		marca = new JTextField();
		marca.setBounds(275, 117, 104, 20);
		Marca.add(marca);
		marca.setColumns(10);
		
		Ano = new JTextField();
		Ano.setBounds(275, 140, 104, 20);
		Marca.add(Ano);
		Ano.setColumns(10);
		
		JLabel modelo = new JLabel("Modelo  :");
		modelo.setBounds(228, 96, 46, 14);
		Marca.add(modelo);
		
		JLabel lblMarca = new JLabel("Marca   :");
		lblMarca.setBounds(228, 120, 46, 14);
		Marca.add(lblMarca);
		
		JLabel lblAno = new JLabel("Ano      :");
		lblAno.setBounds(228, 143, 46, 14);
		Marca.add(lblAno);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(10, 236, 181, 14);
		Marca.add(label);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PainelFuncionarios.getInstance().setVisible(true);
				dispose();
			}
		});
		button.setBounds(360, 7, 46, 23);
		Marca.add(button);
	}
}
