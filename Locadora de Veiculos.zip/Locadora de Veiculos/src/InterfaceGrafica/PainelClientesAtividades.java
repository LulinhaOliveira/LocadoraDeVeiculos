package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.HeadlessException;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Execoes.CpfException;
import Execoes.ExisteMultasExeception;
import Execoes.ItensLocadosCheio;
import Execoes.NullExeception;
import Execoes.VeiculoAlugadoExeception;
import Negocio.Fachada.Fachada;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JList;
import javax.swing.JOptionPane;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PainelClientesAtividades extends JFrame {

	private JPanel contentPane;
	private JTextField placa;
	private JTextField telefone;
	private static PainelClientesAtividades instance;
    public static PainelClientesAtividades getInstance() {
		if (PainelClientesAtividades.instance == null) {
			return PainelClientesAtividades.instance = new PainelClientesAtividades();
		}
		return PainelClientesAtividades.instance;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelClientesAtividades frame = new PainelClientesAtividades();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PainelClientesAtividades() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Alugar = new JButton("Alugar Carro");
		Alugar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				try {
					Fachada.getInstance().Alugar(GUI.cpf, placa.getText());
				} catch (ItensLocadosCheio | ExisteMultasExeception | VeiculoAlugadoExeception e) {
					JOptionPane.showConfirmDialog(null,e.toString());
				}
				Fachada.getInstance().SalvarTodosArquivos();
			}
		});
		Alugar.setBounds(10, 44, 127, 23);
		contentPane.add(Alugar);
		
		JButton PagarMultas = new JButton("Pagar Multas");
		PagarMultas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fachada.getInstance().PagarMulta(GUI.cpf, placa.getText());
				Fachada.getInstance().SalvarTodosArquivos();
			}
		});
		PagarMultas.setBounds(10, 78, 127, 23);
		contentPane.add(PagarMultas);
		
		JButton AtualizarTelefone = new JButton("Atualizar Telefone");
		AtualizarTelefone.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Fachada.getInstance().getCc().AtualizarTelefone(GUI.cpf, telefone.getText());
				try {
					JOptionPane.showConfirmDialog(null,"Seu Telefone � -> " + Fachada.getInstance().getCc().buscarCliente(GUI.cpf).getTelefone());
				} catch (HeadlessException | CpfException e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
				}
				Fachada.getInstance().SalvarTodosArquivos();
			}
			});
		AtualizarTelefone.setBounds(10, 112, 127, 23);
		contentPane.add(AtualizarTelefone);
		
		JButton EncerrarConta = new JButton("Encerrar Conta");
		EncerrarConta.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.getInstance().getCc().removerCliente(GUI.cpf);
				} catch (CpfException | NullExeception e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
					e1.printStackTrace();
				}
				Fachada.getInstance().SalvarTodosArquivos();
				GUI.cpf = null;
				GUI.getInstance().setVisible(true);
				JOptionPane.showConfirmDialog(null,"Conta Encerrada");
				dispose();
				
			}
		});
		EncerrarConta.setBounds(10, 161, 127, 23);
		contentPane.add(EncerrarConta);
		
		JLabel lblAesDoCliente = new JLabel("A\u00E7\u00F5es do Cliente");
		lblAesDoCliente.setBounds(228, 11, 103, 34);
		contentPane.add(lblAesDoCliente);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(10, 236, 181, 14);
		contentPane.add(label);
		
		placa = new JTextField();
		placa.setBounds(312, 45, 86, 20);
		contentPane.add(placa);
		placa.setColumns(10);
		
		JLabel lblPlaca = new JLabel("Placa");
		lblPlaca.setBounds(238, 48, 46, 14);
		contentPane.add(lblPlaca);
		
		telefone = new JTextField();
		telefone.setBounds(312, 113, 86, 20);
		contentPane.add(telefone);
		telefone.setColumns(10);
		
		JLabel lblNovoTelefone = new JLabel("Novo Telefone");
		lblNovoTelefone.setBounds(198, 116, 86, 14);
		contentPane.add(lblNovoTelefone);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PainelClientes.getInstance().setVisible(true);
				dispose();
			}
		});
		button.setBounds(378, 11, 46, 23);
		contentPane.add(button);
	}
}
