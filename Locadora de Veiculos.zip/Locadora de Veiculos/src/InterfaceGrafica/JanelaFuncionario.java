package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Dados.ClientesRepositorio;
import Dados.FuncionariosRepositorio;
import Execoes.ContaNaoExisteExeception;
import Negocio.Fachada.Fachada;

import javax.swing.JTextField;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class JanelaFuncionario extends JFrame {
	private JPanel PainelFuncionario;
	private static JanelaFuncionario instance;
	private JTextField loginFuncionario;
	private JPasswordField senhaFuncionario;
	public static JanelaFuncionario getInstance() {
		if (JanelaFuncionario.instance == null) {
			return JanelaFuncionario.instance = new JanelaFuncionario();
		}
		return JanelaFuncionario.instance;
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JanelaFuncionario frame = new JanelaFuncionario();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public JanelaFuncionario() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		PainelFuncionario = new JPanel();
		PainelFuncionario.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(PainelFuncionario);
		PainelFuncionario.setLayout(null);
		
		JLabel lblBemVindoAo = new JLabel("Login Para Funcionarios");
		lblBemVindoAo.setBounds(147, 11, 180, 14);
		PainelFuncionario.add(lblBemVindoAo);
		
		JLabel lblLogincpf = new JLabel("Login (CPF)");
		lblLogincpf.setBounds(10, 73, 68, 14);
		PainelFuncionario.add(lblLogincpf);
		
		loginFuncionario = new JTextField();
		loginFuncionario.setBounds(72, 70, 86, 20);
		PainelFuncionario.add(loginFuncionario);
		loginFuncionario.setColumns(10);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(10, 98, 46, 14);
		PainelFuncionario.add(lblSenha);
		
		senhaFuncionario = new JPasswordField();
		senhaFuncionario.setBounds(72, 95, 86, 20);
		PainelFuncionario.add(senhaFuncionario);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			  String loginaux = loginFuncionario.getText();
			  String senhaaux = new String(senhaFuncionario.getPassword());
			  
			  if(loginaux.equals(GUI.adminlogin) && senhaaux.equals(GUI.adminsenha)) {
				  PainelFuncionarioAdmin.getInstance().setVisible(true);
		    	  loginFuncionario.setText("");
		    	  senhaFuncionario.setText("");
				  dispose();  
			  }else {
					try {
						if(Fachada.getInstance().VerificarContaFuncionario(loginaux, senhaaux) == true) {
							GUI.cpf = loginFuncionario.getText();
							PainelFuncionarios.getInstance().setVisible(true);
							dispose();
							loginFuncionario.setText("");
					    	senhaFuncionario.setText("");
						}
					} catch (ContaNaoExisteExeception e1) {
						JOptionPane.showConfirmDialog(null, e1.toString());
					}	
			  }
						
			 }
				
		});
		btnEntrar.setBounds(72, 134, 89, 23);
		PainelFuncionario.add(btnEntrar);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(10, 236, 181, 14);
		PainelFuncionario.add(label);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.getInstance().setVisible(true);
				dispose();
			}
		});
		button.setBounds(378, 7, 46, 23);
		PainelFuncionario.add(button);
	}
}
