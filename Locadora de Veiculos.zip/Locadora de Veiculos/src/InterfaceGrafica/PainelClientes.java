package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Execoes.CpfException;
import Negocio.Entidades.Veiculo;
import Negocio.Fachada.Fachada;
import Utilitarios.MultaU;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;

import java.awt.TextArea;
import java.awt.Scrollbar;
import java.awt.ScrollPane;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PainelClientes extends JFrame {

	private JPanel contentPane;
	private JTextField Informacoes;
    
	private static PainelClientes instance;
    public static PainelClientes getInstance() {
		if (PainelClientes.instance == null) {
			return PainelClientes.instance = new PainelClientes();
		}
		return PainelClientes.instance;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelClientes frame = new PainelClientes();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}
    
	/**
	 * Create the frame.
	 */
	public PainelClientes() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton ConsultarDados = new JButton("Consultar Dados");
		ConsultarDados.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Informacoes.setText("");
				try {
					GUI.cliente = Fachada.getInstance().ConsultarDadosCliente(GUI.cpf);
				} catch (CpfException e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
					e1.printStackTrace();
				}
				Informacoes.setText("CPF: " + GUI.cliente.getCpf() + "\n" + "Telefone: " + GUI.cliente.getTelefone() + "\n" + "Nome: " + GUI.cliente.getNome());
				GUI.cliente = null;
			}
		});
		ConsultarDados.setBounds(10, 66, 127, 23);
		contentPane.add(ConsultarDados);
		
		JButton VerificarMultas = new JButton("Verificar Multas");
		VerificarMultas.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Informacoes.setText("");
				MultaU[] multaaux = Fachada.getInstance().VerificarMultas(GUI.cpf);
				if (multaaux != null){
					for(int i = 0 ; i < multaaux.length ; i++) {
						Informacoes.setText("Placa Veiculo: " + multaaux[i].getPlacaVeiculo() + "\n" + "Pre�o Total:" + multaaux[i].getPrecoTotal() + "\n" + "Dias de Atraso:"+ multaaux[i].getDiasAtraso() + "\n" + "Pre�o da Multa:" + multaaux[i].getPrecoMulta() + "\n\n");
					}
					multaaux = null;
				}
			}
		});
		VerificarMultas.setBounds(10, 100, 127, 23);
		contentPane.add(VerificarMultas);
		
		JButton VerLocacoes = new JButton("Ver Itens Locados");
		VerLocacoes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Informacoes.setText("");
				Veiculo[] locados = Fachada.getInstance().VerLocacoes(GUI.cpf);
				if (locados != null) {
					for(int i = 0 ; i < locados.length ; i++) {
						
						Informacoes.setText("Placa Veiculo: " + locados[i].getPlaca() + "\n" + "Modelo: " + locados[i].getModelo() + "\n" + "Marca: " + locados[i].getMarca() + "\n" + "Cor: " + locados[i].getCor() + "\n" + "Ano: " + locados[i].getAno() + "\n" + "Preco:" + locados[i].getPreco());
					}
					locados = null;
				}
			}
		});
		VerLocacoes.setBounds(10, 134, 127, 23);
		contentPane.add(VerLocacoes);
		
		JButton Atividades = new JButton("A\u00E7\u00F5es");
		Atividades.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PainelClientesAtividades.getInstance().setVisible(true);
				Informacoes.setText("");
				dispose();
			}
		});
		Atividades.setBounds(10, 168, 127, 23);
		contentPane.add(Atividades);
		
		JLabel lblPainelDosClientes = new JLabel("Painel Dos Clientes");
		lblPainelDosClientes.setBounds(253, 11, 97, 23);
		contentPane.add(lblPainelDosClientes);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(10, 236, 181, 14);
		contentPane.add(label);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(186, 45, 219, 193);
		contentPane.add(scrollPane);
		
		Informacoes = new JTextField();
		scrollPane.setViewportView(Informacoes);
		Informacoes.setColumns(10);
		
		JButton btnSair = new JButton("SAIR");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {				
				GUI.getInstance().setVisible(true);
				GUI.cpf = null;
				Informacoes.setText("");
				dispose();
			}
		});
		btnSair.setBounds(10, 11, 89, 23);
		contentPane.add(btnSair);
	}
}
