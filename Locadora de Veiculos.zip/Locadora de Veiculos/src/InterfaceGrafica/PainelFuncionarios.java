package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;

public class PainelFuncionarios extends JFrame {

	private JPanel contentPane;
	
	private static PainelFuncionarios instance;
    
	public static PainelFuncionarios  getInstance() {
		if (PainelFuncionarios .instance == null) {
			return PainelFuncionarios.instance = new PainelFuncionarios ();
		}
		return PainelFuncionarios .instance;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelFuncionarios frame = new PainelFuncionarios();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PainelFuncionarios() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton Clientes = new JButton("Clientes");
		Clientes.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				PainelFuncionariosClientes.getInstance().setVisible(true);
				dispose();
			}
		});
		Clientes.setBounds(24, 89, 89, 23);
		contentPane.add(Clientes);
		
		JButton Veiculos = new JButton("Veiculos");
		Veiculos.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PainelFuncionariosVeiculos.getInstance().setVisible(true);
				dispose();
			}
		});
		Veiculos.setBounds(24, 123, 89, 23);
		contentPane.add(Veiculos);
		
		JLabel lblPainelDosFuncionarios = new JLabel("Painel dos Funcionarios");
		lblPainelDosFuncionarios.setBounds(158, 28, 129, 14);
		contentPane.add(lblPainelDosFuncionarios);
		
		JLabel lblByLulinha = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		lblByLulinha.setBounds(10, 236, 181, 14);
		contentPane.add(lblByLulinha);
		
		JLabel lblClientesCadastro = new JLabel("Clientes -> Cadastro / Remo\u00E7\u00E3o / Devolu\u00E7\u00E3o ");
		lblClientesCadastro.setBounds(173, 93, 240, 14);
		contentPane.add(lblClientesCadastro);
		
		JLabel lblVeiculosCadastro = new JLabel("Veiculos -> Cadastro / Remoc\u00E3o / Atualiza\u00E7\u00E3o");
		lblVeiculosCadastro.setBounds(173, 127, 251, 14);
		contentPane.add(lblVeiculosCadastro);
		
		JButton btnSair = new JButton("SAIR");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.getInstance().setVisible(true);
				GUI.cpf = null;
				dispose();
			}
		});
		btnSair.setBounds(10, 11, 89, 23);
		contentPane.add(btnSair);
	}

}
