package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Execoes.ContaNaoExisteExeception;
import Execoes.CpfException;
import Execoes.NullExeception;
import Negocio.Entidades.Funcionario;
import Negocio.Fachada.Fachada;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PainelFuncionarioAdmin extends JFrame {

	private JPanel contentPane;
	private JTextField cpf;
	private JTextField nome;
	private static PainelFuncionarioAdmin instance;
	private JTextField telefone;
	private JPasswordField senha1;
    
	public static PainelFuncionarioAdmin  getInstance() {
		if (PainelFuncionarioAdmin .instance == null) {
			return PainelFuncionarioAdmin.instance = new PainelFuncionarioAdmin ();
		}
		return PainelFuncionarioAdmin .instance;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelFuncionarioAdmin frame = new PainelFuncionarioAdmin();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PainelFuncionarioAdmin() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JButton botaocf =  new JButton("Cadastrar Funcionario");
		botaocf.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String cpfaux = cpf.getText();
				String nomeaux = nome.getText();
				String senhaaux = new String(senha1.getPassword());
				String telefoneaux = telefone.getText();								
				try {
				    Fachada.getInstance().getFc().cadastroFuncionario(nomeaux, cpfaux, senhaaux, telefoneaux);

				} catch (CpfException | NullExeception e1) {
				JOptionPane.showConfirmDialog(null,e1.toString());
				}
				
				try {
					if(Fachada.getInstance().VerificarContaFuncionario(cpfaux, senhaaux) == true) {
						JFrame frame = new JFrame("Cadastrado!");
						JOptionPane.showMessageDialog(frame, "Funcionario cadastrado com sucesso");
					}
				} catch (ContaNaoExisteExeception e1) {
					JFrame frameErro = new JFrame("Erro!");
					JOptionPane.showMessageDialog(frameErro, "Erro ao cadastrar funcionario", "", JOptionPane.ERROR_MESSAGE);
				}
			}
		});
		botaocf.setBounds(32, 57, 173, 23);
		contentPane.add(botaocf);
		
		JButton btnDemitirFuncionario = new JButton("Demitir Funcionario");
		btnDemitirFuncionario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.getInstance().getFc().removerFuncionario(cpf.getText());
				} catch (CpfException e1) {
					JOptionPane.showConfirmDialog(null,e1.ToString());
					e1.printStackTrace();
				}
				Fachada.getInstance().SalvarTodosArquivos();
			}
		});
		btnDemitirFuncionario.setBounds(32, 97, 173, 23);
		contentPane.add(btnDemitirFuncionario);
		
		JLabel lblAdmin = new JLabel("Admin");
		lblAdmin.setBounds(193, 11, 46, 14);
		contentPane.add(lblAdmin);
		
		cpf = new JTextField();
		cpf.setBounds(32, 159, 86, 20);
		contentPane.add(cpf);
		cpf.setColumns(10);
		
		nome = new JTextField();
		nome.setBounds(32, 208, 162, 20);
		contentPane.add(nome);
		nome.setColumns(10);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setBounds(54, 134, 46, 14);
		contentPane.add(lblCpf);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBounds(212, 134, 46, 14);
		contentPane.add(lblSenha);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setBounds(54, 190, 46, 14);
		contentPane.add(lblNome);
		
		JLabel lblCadastrotodosOsCampos = new JLabel("Cadastro->Todos os Campos");
		lblCadastrotodosOsCampos.setBounds(262, 61, 162, 14);
		contentPane.add(lblCadastrotodosOsCampos);
		
		JLabel lblRemoverCpf = new JLabel("Remover-> CPF");
		lblRemoverCpf.setBounds(262, 86, 115, 14);
		contentPane.add(lblRemoverCpf);
		
		JButton btnSair = new JButton("SAIR");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				GUI.getInstance().setVisible(true);
				dispose();
			}
		});
		btnSair.setBounds(11, 7, 89, 23);
		contentPane.add(btnSair);
		
		telefone = new JTextField();
		telefone.setBounds(291, 208, 86, 20);
		contentPane.add(telefone);
		telefone.setColumns(10);
		
		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setBounds(233, 211, 46, 14);
		contentPane.add(lblTelefone);
		
		senha1 = new JPasswordField();
		senha1.setBounds(212, 159, 86, 20);
		contentPane.add(senha1);
		senha1.setColumns(10);
	}

}
