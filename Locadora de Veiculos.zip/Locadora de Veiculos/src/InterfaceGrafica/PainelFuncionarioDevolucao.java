package InterfaceGrafica;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Execoes.KMExeception;
import Execoes.NullExeception;
import Execoes.PlacaValidacaoExeception;
import Negocio.Fachada.Fachada;

import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import java.awt.TextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class PainelFuncionarioDevolucao extends JFrame {

	private JPanel contentPane;
	private JTextField cpf;
	private JTextField placa;
	private JTextField diasatraso;
	private JTextField novakm;
	private JTextField informacoes;
	private static PainelFuncionarioDevolucao instance;
    public static PainelFuncionarioDevolucao getInstance() {
		if (PainelFuncionarioDevolucao.instance == null) {
			return PainelFuncionarioDevolucao.instance = new PainelFuncionarioDevolucao();
		}
		return PainelFuncionarioDevolucao.instance;
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PainelFuncionarioDevolucao frame = new PainelFuncionarioDevolucao();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PainelFuncionarioDevolucao() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		cpf = new JTextField();
		cpf.setBounds(33, 49, 86, 20);
		contentPane.add(cpf);
		cpf.setColumns(10);
		
		placa = new JTextField();
		placa.setBounds(33, 91, 86, 20);
		contentPane.add(placa);
		placa.setColumns(10);
		
		diasatraso = new JTextField();
		diasatraso.setBounds(33, 131, 86, 20);
		contentPane.add(diasatraso);
		diasatraso.setColumns(10);
		
		novakm = new JTextField();
		novakm.setBounds(33, 173, 86, 20);
		contentPane.add(novakm);
		novakm.setColumns(10);
		
		JLabel lblNewLabel = new JLabel("Painel dos Funcionarios -- Devolu\u00E7\u00E3o");
		lblNewLabel.setBounds(148, 11, 188, 14);
		contentPane.add(lblNewLabel);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setBounds(148, 52, 46, 14);
		contentPane.add(lblCpf);
		
		JLabel lblPlaca = new JLabel("Placa");
		lblPlaca.setBounds(148, 94, 46, 14);
		contentPane.add(lblPlaca);
		
		JLabel lblDiasAtraso = new JLabel("Dias Atraso");
		lblDiasAtraso.setBounds(148, 134, 103, 14);
		contentPane.add(lblDiasAtraso);
		
		JLabel lblNovaQuilometragem = new JLabel("Nova Quilometragem");
		lblNovaQuilometragem.setBounds(148, 176, 129, 14);
		contentPane.add(lblNovaQuilometragem);
		
		JButton btnDevolver = new JButton("Devolver");
		btnDevolver.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					Fachada.getInstance().Devolver(cpf.getText(), placa.getText(),Integer.parseInt(diasatraso.getText()), Integer.parseInt(novakm.getText()));
				} catch (NumberFormatException | PlacaValidacaoExeception | NullExeception | KMExeception e1) {
					JOptionPane.showConfirmDialog(null,e1.toString());
				}
				Fachada.getInstance().SalvarTodosArquivos();
				JOptionPane.showConfirmDialog(null,"Devolu��o Feita");
			}
		});
		btnDevolver.setBounds(297, 48, 89, 23);
		contentPane.add(btnDevolver);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(275, 91, 137, 106);
		contentPane.add(scrollPane);
		
		informacoes = new JTextField();
		scrollPane.setViewportView(informacoes);
		informacoes.setColumns(10);
		
		JButton btnGerarTotal = new JButton("Gerar Total");
		btnGerarTotal.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			informacoes.setText("");
			double pmaux = Fachada.getInstance().getMr().GerarPrecoMulta(GUI.cpf, placa.getText(), Integer.parseInt(diasatraso.getText()));
			double pv = Fachada.getInstance().PrecoVeiculo(placa.getText());
			double total = pmaux + pv;
			informacoes.setText("Pre�o da Multa: "+ pmaux + "\n" + "Pre�o do Veiculo:"+ pv + "\n"+ "Pre�o Total" + total );
			
			
			pmaux = 0;
			pv =0;
			total= 0;
			
			}
		});
		btnGerarTotal.setBounds(297, 208, 89, 23);
		contentPane.add(btnGerarTotal);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(13, 236, 181, 14);
		contentPane.add(label);
		
		JButton button = new JButton("<-");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				PainelFuncionarioDevolucao.getInstance().setVisible(true);
				informacoes.setText("");
				dispose();
			}
		});
		button.setBounds(378, 7, 46, 23);
		contentPane.add(button);
	}
}
