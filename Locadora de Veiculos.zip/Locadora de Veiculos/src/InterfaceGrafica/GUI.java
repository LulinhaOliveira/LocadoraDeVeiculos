package InterfaceGrafica;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import Negocio.Entidades.Cliente;
import Negocio.Entidades.Funcionario;
import Negocio.Entidades.Locacao;
import Negocio.Entidades.Multas;
import Negocio.Entidades.Veiculo;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class GUI extends JFrame {
	static String cpf;
	static String adminlogin = "luiz";
	static String adminsenha = "luiz";
	static Funcionario funcionario=null;
	static Cliente cliente =null;
	static Locacao locacao=null;
	static Multas multa=null;
	static Veiculo veiculo=null;
	static GUI instance;
	private JPanel menuInicial;

	/**
	 * Launch the application.
	 */
	public static GUI getInstance() {
		if (GUI.instance == null) {
			return GUI.instance = new GUI();
		}
		return GUI.instance;
	}
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					GUI frame = new GUI();
					frame.setVisible(true);
				} catch (Exception e) {
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public GUI() {
		

		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		menuInicial = new JPanel();
		menuInicial.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(menuInicial);
		menuInicial.setLayout(null);
		
		JLabel lblSejaBemVindo = new JLabel("Seja bem vindo a locadora de ve\u00EDculos");
		lblSejaBemVindo.setBounds(118, 11, 349, 39);
		menuInicial.add(lblSejaBemVindo);
		
		JLabel lblEscolhaSeuPainel = new JLabel("Escolha seu painel de navega\u00E7\u00E3o abaixo");
		lblEscolhaSeuPainel.setBounds(107, 89, 255, 14);
		menuInicial.add(lblEscolhaSeuPainel);
		
		JButton btnCliente = new JButton("Cliente");
		btnCliente.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JanelaCliente.getInstance().setVisible(true);
				dispose();
			}
		});
		btnCliente.setBounds(43, 129, 89, 23);
		menuInicial.add(btnCliente);
		
		JButton btnFuncionario = new JButton("Funcionario");
		btnFuncionario.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				JanelaFuncionario.getInstance().setVisible(true);
                dispose();
			}
		});
		btnFuncionario.setBounds(271, 129, 107, 23);
		menuInicial.add(btnFuncionario);
		
		JLabel label = new JLabel("by : Lulinha && M\u00E3odeGolfinho");
		label.setBounds(10, 236, 181, 14);
		menuInicial.add(label);
		
		JButton btnFechar = new JButton("Fechar");
		btnFechar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose ();

			}
		});
		btnFechar.setBounds(154, 187, 89, 23);
		menuInicial.add(btnFechar);
	}
}
