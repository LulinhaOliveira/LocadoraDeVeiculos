package Utilitarios;

import java.io.Serializable;

public class MultaU implements Serializable {
	private boolean MultaStatus;
	private String PlacaVeiculo;
	private double PrecoMulta;
	private int diasAtraso;
    private double precoTotal;
    
    MultaU(String placaVeiculo, double PrecoMulta, int diasAtraso, double precoTotal){
    	this.PrecoMulta = PrecoMulta;
    	this.diasAtraso = diasAtraso;
    	this.precoTotal = precoTotal;
    }
    
	public boolean isMultaStatus() {
		return MultaStatus;
	}
	public void setMultaStatus(boolean multaStatus) {
		MultaStatus = multaStatus;
	}
	public String getPlacaVeiculo() {
		return PlacaVeiculo;
	}
	public void setPlacaVeiculo(String placaVeiculo) {
		PlacaVeiculo = placaVeiculo;
	}
	public double getPrecoMulta() {
		return PrecoMulta;
	}
	public void setPrecoMulta(double precoMulta) {
		PrecoMulta = precoMulta;
	}
	public int getDiasAtraso() {
		return diasAtraso;
	}
	public void setDiasAtraso(int diasAtraso) {
		this.diasAtraso = diasAtraso;
	}
	public double getPrecoTotal() {
		return precoTotal;
	}
	public void setPrecoTotal(double precoTotal) {
		this.precoTotal = precoTotal;
	}
}
