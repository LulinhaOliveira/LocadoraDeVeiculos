package Utilitarios;

import java.io.Serializable;

public class Pessoa implements Comparable<Pessoa>, Serializable{
	private String cpf;
	private String nome;
	private String senha;
    private String telefone;

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		this.cpf = cpf;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public Pessoa(String nome, String cpf, String senha , String telefone) {
		this.nome = nome;
		this.cpf = cpf;		
		this.senha = senha;
		this.telefone = telefone;
	}

	@Override
	public int compareTo(Pessoa arg0) {		
		return this.nome.compareTo(arg0.getNome());
	}

	public String getTelefone() {
		return telefone;
	}

	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}	
}