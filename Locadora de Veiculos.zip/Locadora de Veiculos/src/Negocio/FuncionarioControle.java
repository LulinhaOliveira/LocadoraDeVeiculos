package Negocio;

import java.util.Arrays;

import Dados.FuncionariosRepositorio;
import Dados.IRepositorioFuncionario;
import Execoes.ContaNaoExisteExeception;
import Execoes.CpfException;
import Execoes.NullExeception;
import Negocio.Entidades.Funcionario;

public class FuncionarioControle {
	private IRepositorioFuncionario funcionarios;
	public IRepositorioFuncionario getFuncionario() {
		return funcionarios;
	}
	public void setFuncionarios(IRepositorioFuncionario funcionarios) {
		this.funcionarios = funcionarios;
	}
	Funcionario funcionario;
	
	public FuncionarioControle(){
		funcionarios = FuncionariosRepositorio.getInstance();
	}
	
	public boolean ContaExisteFuncionario(String cpf , String senha) throws ContaNaoExisteExeception {
		for(int i = 0 ; i < funcionarios.getFuncionario().length ; i ++) {
			if(funcionarios.getFuncionario()[i] == null) {
				continue;
			}
			if(funcionarios.getFuncionario()[i].getCpf().equals(cpf)) {
				if(funcionarios.getFuncionario()[i].getSenha().equals(senha)) {
					return true;
				}
			}
		}
		throw new ContaNaoExisteExeception();
	}
	public boolean validarCPF(String cpf) {
		int i, j, digito2 = 0;
		if(cpf.length() != 11)
			return false;
		else if((cpf == "00000000000") || (cpf == "11111111111") || (cpf == "22222222222") ||
				(cpf == "33333333333") || (cpf == "44444444444") || (cpf == "55555555555") ||
				(cpf == "66666666666") || (cpf == "77777777777") || (cpf == "88888888888") ||
				(cpf == "99999999999"))
			return false;
		else {
			for(i = 0, j = 11; i < cpf.length() - 1; i++, j--){
				digito2 += (cpf.charAt(i) - 48) * j;
				digito2 *= 11;
			}
			if(digito2 < 2){
				digito2 = 0;

			}else {
				digito2 = 11 - digito2;
			}
			return true;
		}

	}

	public void cadastroFuncionario(String nome, String cpf, String senha, String telefone) throws CpfException, NullExeception {
		if(nome != "" && cpf != "" && senha != "") {
			if(validarCPF(cpf) == true) {
				funcionario = new Funcionario(nome, cpf, senha, telefone);
				funcionarios.inserirFuncionario(funcionario);
				Arrays.sort(funcionarios.getFuncionario());
			} else {
				throw new CpfException(cpf);
			}
		} else {
			throw new NullExeception();
		}
	}

	public void removerFuncionario(String cpf) throws CpfException {
		if(validarCPF(funcionario.getCpf()) == true) {
			funcionarios.removerFuncionario(cpf);
			Arrays.sort(this.funcionarios.getFuncionario());
		} else {
			throw new CpfException(cpf);
		}
	}

	public void buscarFuncionario(String cpf) throws CpfException {
		if(validarCPF(funcionario.getCpf()) == true) {
			funcionarios.buscarFuncionario(cpf);
			Arrays.sort(this.funcionarios.getFuncionario());
		} else {
			throw new CpfException(cpf);
		}
	}
	public void AtualizarTelefone(String cpf , String telefone) {
		funcionarios.buscarFuncionario(cpf).setTelefone(telefone);
	}
}