package Negocio;



import java.util.Calendar;
import java.util.GregorianCalendar;

import Dados.IRepositorioLocacoes;
import Dados.LocacoesRepositorio;
import Execoes.ExisteItensLocadosExeception;
import Execoes.ItensLocadosCheio;
import Negocio.Entidades.Locacao;
import Utilitarios.Data;

public class LocacaoControle {
	private IRepositorioLocacoes locacoes;
	Locacao locacao;

	public LocacaoControle(){
		locacoes = LocacoesRepositorio.getInstance();
	}
	
	public IRepositorioLocacoes getLocacoes() {
		return locacoes;
	}

	public void setLocacoes(LocacoesRepositorio locacoes) {
		this.locacoes = locacoes;
	}
	
	static Calendar cal = GregorianCalendar.getInstance(); 
	public boolean VerificarExistenciaItens(String cpf) {
		for(int i = 0; i < locacoes.getLocacao().length ; i++) {
			if(locacoes == null) {
				continue;
			}
			if(locacoes.getLocacao()[i].getClienteCPF().equals(cpf)) {
				for(int z = 0 ; z < locacoes.getLocacao()[i].getVeiculosLocados().length ; z++) {
					if(locacoes.getLocacao()[i].getVeiculosLocados()[z] != null) {
						return true;
					}
				}
			}
		}
		return false;
	}

	public int VerificarQtItensLocados( int indiceLocador) {
		int qt = 0;

		for(int z = 0 ; z < locacoes.getLocacao()[indiceLocador].getVeiculosLocados().length ; z++) {
			if(locacoes == null) {
				continue;
			}
			if(locacoes.getLocacao()[indiceLocador].getVeiculosLocados()[z] != null ) {
				qt++;
			}
		}
		return qt;
	}
    
	public void Cadastrolocacao(String cpf) {
		if(cpf != "") {
			locacao = new Locacao(cpf);
			locacoes.inserirLocacao(locacao);
		}
	}
	public void Removelocacao(String cpf) throws ExisteItensLocadosExeception {
		if(cpf != null) {
			if((VerificarExistenciaItens(cpf) != true)) {
				locacoes.removerLocacao(cpf);	
			}else {
				throw new ExisteItensLocadosExeception();
			}
		}
	}
	public Locacao Procuralocacao(String cpf) {
		if(cpf != null) {
			return locacoes.buscarLocacao(cpf);
		}
		return null;
	}

	public void removeItenLocados(String cpf,String placa) {
		for(int i = 0; i < locacoes.getLocacao().length ; i++) {
			if(this.locacoes.getLocacao()[i].getClienteCPF().equals(cpf)) {
				for(int z = 0; z < locacoes.getLocacao()[i].getVeiculosLocados().length ; z++) {
					if(locacoes.getLocacao()[i].getVeiculosLocados()[z].getPlacaVeiculo().equals(placa)) {
						locacoes.getLocacao()[i].getVeiculosLocados()[z] = null;					
						break;
					}
				}
			}
		}
	}
	public void addItenLocaods(String cpf,String placa ) throws ItensLocadosCheio {
		Data devo , locado;
		locado = new Data(cal.get(Calendar.DAY_OF_MONTH),cal.get(Calendar.MONTH),cal.get(Calendar.YEAR));	
		devo = locado;
		devo.setDia(devo.getDia()+ 7);
		for(int i = 0; i < locacoes.getLocacao().length ; i++) {
			if(this.locacoes.getLocacao()[i].getClienteCPF().equals(cpf)) {
				if(VerificarQtItensLocados(i) != 5) {
					for(int z = 0; z < locacoes.getLocacao()[i].getVeiculosLocados().length ; z++) {
						if(locacoes.getLocacao()[i].getVeiculosLocados()[z] == null) {
							locacoes.getLocacao()[i].getVeiculosLocados()[z].setPlacaVeiculo(placa); 
							locacoes.getLocacao()[i].getVeiculosLocados()[z].setDataDevolucao(devo);
							locacoes.getLocacao()[i].getVeiculosLocados()[z].setDataLocado(locado);
							break;	
						}
					}
				}else {
					throw new ItensLocadosCheio();
				}
			}
		}	
	}
}