package Negocio.Fachada;

import Negocio.MultaControle;

import java.util.Arrays;

import Execoes.AnoValidarExeception;
import Execoes.ContaNaoExisteExeception;
import Execoes.CpfException;
import Execoes.ExisteItensLocadosExeception;
import Execoes.ExisteMultasExeception;
import Execoes.ItensLocadosCheio;
import Execoes.KMExeception;
import Execoes.NullExeception;
import Execoes.PlacaExisteExeception;
import Execoes.PlacaNaoExiste;
import Execoes.PlacaValidacaoExeception;
import Execoes.VeiculoAlugadoExeception;
import Negocio.ControleClientes;
import Negocio.FuncionarioControle;
import Negocio.LocacaoControle;
import Negocio.VeiculoControle;
import Negocio.Entidades.*;
import Utilitarios.MultaU;

public class Fachada {
	private VeiculoControle vc;     
	private ControleClientes cc;     
	private FuncionarioControle fc; 
	private LocacaoControle lc;     
	private MultaControle mr; 
	static Fachada instance;
	private Fachada() {
		vc = new VeiculoControle();
		cc = new ControleClientes();
		fc = new FuncionarioControle();
		lc = new LocacaoControle();
		mr = new MultaControle();
	}
	
	public static Fachada getInstance() {
		if(Fachada.instance == null) {
			return Fachada.instance = new Fachada();
		}
		return Fachada.instance;
	}
	
	public VeiculoControle getVc() {
		return vc;
	}
	public void setVc(VeiculoControle vc) {
		this.vc = vc;
	}
	public ControleClientes getCc() {
		return cc;
	}
	public void setCc(ControleClientes cc) {
		this.cc = cc;
	}
	public FuncionarioControle getFc() {
		return fc;
	}
	public void setFc(FuncionarioControle fc) {
		this.fc = fc;
	}
	public LocacaoControle getLc() {
		return lc;
	}
	public void setLc(LocacaoControle lc) {
		this.lc = lc;
	}
	public MultaControle getMr() {
		return mr;
	}
	public void setMr(MultaControle mr) {
		this.mr = mr;
	}
	

	public void SalvarTodosArquivos() {
	vc.getVeiculo().salvarArquivo();
	lc.getLocacoes().salvarArquivo();
	cc.getClientes().salvarArquivo();
	mr.getMultas().salvarArquivo();
	fc.getFuncionario().salvarArquivo();
	}
	
	public void CadastrarCliente(String nome, String cpf, String senha, String telefone, String cpfL , String cpfM) throws CpfException, NullExeception {
		cc.cadastroCliente(nome, cpf, senha, telefone);
		lc.Cadastrolocacao(cpfL);
		mr.CadastraMulta(cpfM);
	}
	public void RemoverCliente(String cpf) throws CpfException, NullExeception, ExisteItensLocadosExeception, ExisteMultasExeception {
		cc.removerCliente(cpf);
		lc.Removelocacao(cpf);
		mr.RemoverMulta(cpf);
	}
	public void CadastrarVeiculo(String placa , String modelo, String marca , String cor , int ano , double preco) throws PlacaValidacaoExeception, NullExeception, AnoValidarExeception, PlacaExisteExeception {
		vc.Cadastro(placa , modelo,  marca , cor ,ano , preco);
	}
	public void RemoverVeiculo(String placa) throws PlacaValidacaoExeception, NullExeception, PlacaNaoExiste {
		vc.Remocao(placa);
	}

	public boolean VerificarContaCliente(String cpf , String senha) throws ContaNaoExisteExeception {
		return cc.ContaExisteClinte(cpf, senha);
	}
	public boolean VerificarContaFuncionario(String cpf , String senha) throws ContaNaoExisteExeception {
		return fc.ContaExisteFuncionario(cpf, senha);
	}       
	public Cliente ConsultarDadosCliente(String cpf) throws CpfException {
		return cc.buscarCliente(cpf);
	}
	public  Veiculo[] VerLocacoes(String cpf) {
		Locacao locacao;
		Veiculo [] locados = new Veiculo[5];
		int cont = 0;
		locacao = lc.Procuralocacao(cpf);
		if (locacao != null) {
			for(int i = 0 ; i < locacao.getVeiculosLocados().length ; i++) {
				if(locacao == null) {
					Arrays.copyOf(locados, 0);
				}
				for(int z = 0 ; z < vc.getVeiculo().getVeiculo().length ; z++) {
					if(locacao.getVeiculosLocados()[i].getPlacaVeiculo() == vc.getVeiculo().getVeiculo()[z].getPlaca()) {
						locados[cont] = vc.Procura(vc.getVeiculo().getVeiculo()[z].getPlaca());
						cont++;
					}
				}
			}
		}
		return locados;
	}
		

	@SuppressWarnings("null")
	public MultaU[] VerificarMultas(String cpf) {
		Multas multa = null;
		MultaU [] multas = null;
		MultaU [] multasnaopagas = null;
		int cont = 0;

		multa = mr.getMultas().ProcurarMulta(cpf);
		if(multa == null) {
			return new MultaU[0];
		}
		multas = multa.getMultas();

		for(int i = 0 ; i < multas.length ; i++ ) {
			if(multas[i] == null) {
				continue;
			}
			if(multas[i].isMultaStatus() == false) {
				multasnaopagas[cont] = multas[i];
				cont++;
			}
		}     
		return multasnaopagas;    
	}


	public void Alugar(String cpf ,String placa ) throws ItensLocadosCheio, ExisteMultasExeception, VeiculoAlugadoExeception {
		if(mr.ExisteMultas(cpf)== false) {
			if(vc.Procura(placa).isStatus() == true) {
				lc.addItenLocaods(cpf, placa);
				vc.AtualizarStatus(placa); 
			}else {
				throw new VeiculoAlugadoExeception();
			}
		}else {
			throw new ExisteMultasExeception();
		}

	}

	public void Devolver(String cpf , String placa , int diasatraso , int novaKM) throws PlacaValidacaoExeception, NullExeception, KMExeception {
		double precoaux = 0;
		precoaux = PrecoVeiculo(placa);
		mr.GerarMulta(cpf, placa, diasatraso);
		mr.MultaVeiculoValor(placa, cpf,precoaux);
		lc.removeItenLocados(cpf, placa);  
		vc.AtualizaKM(placa, novaKM);
		vc.AtualizarStatus(placa);
	}
	public void PagarMulta(String cpf , String placa) {
		mr.AtualizarStatusMulta(cpf, placa);
	}
	public double PrecoVeiculo(String placa) {
		return vc.Procura(placa).getPreco();
	}
    public boolean ContaAdmin(String login , String senha) {
    	if(login == "admin"  && senha == "admin") {
    		return true;
    	}
    	return false;
    }
}
