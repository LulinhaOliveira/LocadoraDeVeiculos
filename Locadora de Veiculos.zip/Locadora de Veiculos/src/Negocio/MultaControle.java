package Negocio;

import Dados.IRepositorioFuncionario;
import Dados.IRepositorioMultas;
import Dados.MultasRepositorio;
import Execoes.ExisteMultasExeception;
import Negocio.Entidades.Multas;

public class MultaControle {
	private IRepositorioMultas multas;
	Multas multa;
	
    public IRepositorioMultas getMultas() {
		return multas;
	}
	public void setMultas(MultasRepositorio multas) {
		this.multas = multas;
	}
	
	public MultaControle() {
		multas = MultasRepositorio.getInstance();
	}
	
	public boolean ExisteMultas(String cpf) {
    	for(int i = 0 ; i < multas.getMultas().length ; i++) {
    		if(multas == null) {
    			continue;
    		}
    		if(multas.getMultas()[i].getCpfCliente().equals(cpf)) {
    			for(int z = 0 ; z < multas.getMultas()[i].getMultas().length ; z++) {
    				if(multas.getMultas()[i].getMultas()[z].isMultaStatus() == false) {
    				   return true;	
    				}
    			}
    		}
    	}
    	return false;
    }
	public void GerarMulta(String cpf , String placa , int diasatraso) {
		for(int i = 0 ; i < multas.getMultas().length ; i++ ) {
			if(multas.getMultas()[i].getCpfCliente().equals(cpf)) {
				for(int z = 0 ; z < multas.getMultas()[i].getMultas().length ; z++) {
					if(multas.getMultas()[i].getMultas()[z] == null) {
						multas.getMultas()[i].getMultas()[z].setPlacaVeiculo(placa);
						multas.getMultas()[i].getMultas()[z].setDiasAtraso(diasatraso);
						multas.getMultas()[i].getMultas()[z].setMultaStatus(false);
						if(diasatraso == 0) {
							multas.getMultas()[i].getMultas()[z].setPrecoMulta(0);
							multas.getMultas()[i].getMultas()[z].setMultaStatus(true);
						}else if(diasatraso <= 5) {
							multas.getMultas()[i].getMultas()[z].setPrecoMulta(10);
							multas.getMultas()[i].setMultasEmAberto(multas.getMultas()[i].getMultasEmAberto()+ 1);
							multas.getMultas()[i].setTotaldeMultas(multas.getMultas()[i].getTotaldeMultas() + 1);
						}else if(diasatraso >= 5) {
							multas.getMultas()[i].getMultas()[z].setPrecoMulta(20);
							multas.getMultas()[i].setMultasEmAberto(multas.getMultas()[i].getMultasEmAberto()+ 1);
							multas.getMultas()[i].setTotaldeMultas(multas.getMultas()[i].getTotaldeMultas() + 1);
						}

					}
				}
			}
		}
	}
	public void AtualizarStatusMulta(String cpf , String placa) {
		for(int i = 0 ; i > multas.getMultas().length ; i++) {
			if(multas.getMultas()[i].getCpfCliente().equals(cpf)) {
				for(int z = 0 ; z < multas.getMultas()[i].getMultas().length ; z++) {
					if(multas.getMultas()[i].getMultas()[z].getPlacaVeiculo().equals(placa)) {
						multas.getMultas()[i].getMultas()[z].setMultaStatus(true);
						multas.getMultas()[i].setMultasEmAberto(multas.getMultas()[i].getMultasEmAberto() - 1);
					}
				}
			}
		}
	}
	public void MultaVeiculoValor(String placa , String cpf , double preco) {
		for(int i = 0 ; i > multas.getMultas().length;i++) {
			if(multas.getMultas()[i].getCpfCliente().equals(cpf)) {
				for(int z =0 ; z < multas.getMultas()[i].getMultas().length ; z++) {
					if(multas.getMultas()[i].getMultas()[z].getPlacaVeiculo() == placa) {
						  multas.getMultas()[i].getMultas()[z].setPrecoTotal(preco + multas.getMultas()[i].getMultas()[z].getPrecoMulta());
					}
				}
			}
		}
	}
    public double GerarPrecoMulta(String cpf , String placa , int diasatraso) {
         if(diasatraso <= 5 && diasatraso != 0) {
	      return 10;
		}else if(diasatraso >= 5) {
          return 20;
		}
	   return 0;
    }
	public void CadastraMulta(String cpf) {
		for(int i = 0 ; i < multas.getMultas().length ; i++) {
			if(multas.getMultas()[i] == null) {
				multa = new Multas(cpf);
				multas.InserirMulta(multa, i);
			}
		}
	}
	public void RemoverMulta(String cpf) throws ExisteMultasExeception {
		for(int i = 0 ; i < multas.getMultas().length ; i++) {
			if(multas.getMultas()[i].getCpfCliente().equals(cpf)) {
				if(ExisteMultas(cpf) == false) {
					multas.RemoverMulta(i);
				}else {
					throw new ExisteMultasExeception();
				}
			}
		}	
	}
	public Multas ProcuraMulta(String cpf) {
		for(int i = 0 ; i < multas.getMultas().length ; i++) {
			if(multas == null) {
				continue;
			}
			if(multas.getMultas()[i].getCpfCliente().equals(cpf)) {
				return multas.getMultas()[i];
			}
		}
		return null;	
	}
}
