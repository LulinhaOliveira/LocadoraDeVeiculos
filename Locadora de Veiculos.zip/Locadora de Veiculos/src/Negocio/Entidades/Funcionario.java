package Negocio.Entidades;

import java.io.Serializable;

import Utilitarios.Pessoa;

public class Funcionario extends Pessoa implements Serializable{

	public Funcionario(String nome, String cpf, String senha ,String telefone) {
		super(nome, cpf, senha ,telefone);
	}

}
