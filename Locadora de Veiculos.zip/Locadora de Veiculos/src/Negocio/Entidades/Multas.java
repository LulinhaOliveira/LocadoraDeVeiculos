package Negocio.Entidades;

import java.io.Serializable;

import Utilitarios.MultaU;

public class Multas implements Serializable{

	private String cpfCliente;
	private MultaU[] multas; 
	private int totaldeMultas;
	private int multasEmAberto;


	public int getTotaldeMultas() {
		return totaldeMultas;
	}
	public void setTotaldeMultas(int totaldeMultas) {
		this.totaldeMultas = totaldeMultas;
	}
	public int getMultasEmAberto() {
		return multasEmAberto;
	}
	public void setMultasEmAberto(int multasEmAberto) {
		this.multasEmAberto = multasEmAberto;
	}
	public String getCpfCliente() {
		return cpfCliente;
	}
	public void setCpfCliente(String cpfCliente) {
		this.cpfCliente = cpfCliente;
	}

	public Multas(String cpfCliente) {
		this.cpfCliente = cpfCliente;
		this.totaldeMultas = 0;
		this.multasEmAberto = 0;
		multas = new MultaU[100];
	}
	public MultaU [] getMultas() {
		return multas;
	}
	public void setMultas(MultaU [] multas) {
		this.multas = multas;
	}

}
