
package Negocio;

import java.util.Arrays;

import Dados.ClientesRepositorio;
import Dados.IRepositorioCliente;
import Execoes.ContaNaoExisteExeception;
import Execoes.CpfException;
import Execoes.NullExeception;
import Negocio.Entidades.Cliente;

public class ControleClientes {
	private IRepositorioCliente clientes;
	Cliente cliente;

	public ControleClientes() {
		clientes = ClientesRepositorio.getInstance();
	}
	
	public IRepositorioCliente getClientes() {
		return clientes;
	}
	public void setClientes(ClientesRepositorio clientes) {
		this.clientes = clientes;
	}
	public boolean ContaExisteClinte(String cpf , String senha) throws ContaNaoExisteExeception {
		for(int i = 0 ; i < clientes.getCliente().length ; i++) {
			if(clientes.getCliente()[i] == null) {
				continue;
			}
			if(clientes.getCliente()[i].getCpf().equals(cpf)) {
				if(clientes.getCliente()[i].getSenha().equals(senha)) {
					return true;
				}
			}
		}
		throw new ContaNaoExisteExeception();
	}
	public boolean validarCPF(String cpf) {
		int i, j, digito2 = 0;
		if(cpf.length() != 11)
			return false;
		else if((cpf == "00000000000") || (cpf == "11111111111") || (cpf == "22222222222") ||
				(cpf == "33333333333") || (cpf == "44444444444") || (cpf == "55555555555") ||
				(cpf == "66666666666") || (cpf == "77777777777") || (cpf == "88888888888") ||
				(cpf == "99999999999"))
			return false;
		else {
			for(i = 0, j = 11; i < cpf.length() - 1; i++, j--){
				digito2 += (cpf.charAt(i) - 48) * j;
				digito2 *= 11;
			}
			if(digito2 < 2){
				digito2 = 0;

			}else {
				digito2 = 11 - digito2;
			}
			return true;
		}

	}

	public void cadastroCliente(String nome, String cpf, String senha, String telefone) throws CpfException, NullExeception {
		if(nome != "" && cpf != "" && senha != "") {
			if(validarCPF(cpf)== true) {
				cliente = new Cliente(nome, cpf, senha, telefone);
				clientes.inserirCliente(cliente);
				Arrays.sort(this.clientes.getCliente());
			} else {
				throw new CpfException(cpf);
			}
		} else {
			throw new NullExeception();
		}
	}

	public void removerCliente(String cpf) throws CpfException, NullExeception {
		if(validarCPF(cliente.getCpf()) == true) {
			clientes.removerCliente(cpf);
			Arrays.sort(this.clientes.getCliente());
		} else {
			throw new CpfException(cpf);
		}
	}

	public Cliente buscarCliente(String cpf) throws CpfException {
		if(validarCPF(cliente.getCpf()) == true) {
			return clientes.buscarCliente(cpf);
		} else {
			throw new CpfException(cpf);
		}
	}
    public void AtualizarTelefone(String cpf , String telefone) {
    	clientes.buscarCliente(cpf).setTelefone(telefone);
    }
	public void atualizarCliente(String cpf) throws CpfException {
		if(validarCPF(cliente.getCpf()) == true) {
			clientes.atualizarCliente(cpf);
			Arrays.sort(this.clientes.getCliente());
		} else {
			throw new CpfException(cpf);
		}
	}
}
