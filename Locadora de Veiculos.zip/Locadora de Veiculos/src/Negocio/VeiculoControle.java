package Negocio;

import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Calendar;
import java.util.GregorianCalendar;

import Dados.IRepositorioCliente;
import Dados.IRepositorioVeiculos;
import Dados.VeiculosRepositorio;
import Execoes.AnoValidarExeception;
import Execoes.KMExeception;
import Execoes.NullExeception;
import Execoes.PlacaExisteExeception;
import Execoes.PlacaNaoExiste;
import Execoes.PlacaValidacaoExeception;
import Execoes.PrecoExeception;
import Execoes.VeiculoAlugadoExeception;
import Negocio.Entidades.Veiculo;

public class VeiculoControle {
	static Calendar cal = GregorianCalendar.getInstance(); 
	private IRepositorioVeiculos veiculo;
	
	public VeiculoControle() {
		veiculo = VeiculosRepositorio.getInstance();
	}

	public IRepositorioVeiculos getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(VeiculosRepositorio veiculo) {
		this.veiculo = veiculo;
	}
	
	//Placa Deve Estar no Padr�o
	public static int ValidarPlaca(String placa) {
		int fim=0;
		Pattern pattern = Pattern.compile("[a-zA-Z]{3}-?[0-9]{4}");
		Matcher matcher = pattern.matcher(placa);
		if(matcher.find()){
			fim = matcher.end();
		}
        if(fim==8){
    		return 0;			
		}
        return 1;
	}
	//Ano Deve Ser Menor Que o Atual
	public static int ValidarAno(int ano) {
		if(ano <= cal.get(Calendar.YEAR)){
			return 1;
		}
		return 0;
	}
	public int VerificarPlacaExiste(String placa) {
       if(veiculo.Procurar(placa) == null) {
    	  return 1 ;
       }

		return 0;
	}



	public void Cadastro(String placa , String modelo, String marca , String cor , int ano , double preco) throws PlacaValidacaoExeception, NullExeception, AnoValidarExeception, PlacaExisteExeception {
		if(placa != "" || modelo != "" || cor != "" || ano != 0 || preco != 0) {
			if(ValidarPlaca(placa)==0) {		
				if(ValidarAno(ano)== 1){	
					if(VerificarPlacaExiste(placa) == 1 ) {			
								Veiculo veiculo = new Veiculo(placa , marca , modelo ,cor ,ano ,preco);
								this.veiculo.Inserir(veiculo);
								Arrays.sort(this.veiculo.getVeiculo());
						
					}else {
						throw new PlacaExisteExeception(placa);
				 }
				}else {
					throw new AnoValidarExeception(ano);
				}
			}else {
				throw new PlacaValidacaoExeception(placa);
			}
		}else {
			throw new NullExeception();
		}
	}


	public void Remocao(String placa) throws PlacaValidacaoExeception, NullExeception, PlacaNaoExiste {
		if(placa != "") {
			if(ValidarPlaca(placa) == 0) {
				if(VerificarPlacaExiste(placa) == 0) {
					this.veiculo.Remover(placa);
			//		Arrays.sort(this.veiculo.getVeiculo());
				}else {
					throw new PlacaNaoExiste();
				}
		}else {
			throw new PlacaValidacaoExeception(placa);
		}
		}else {
			throw new NullExeception();
		}
	}

	public void AtualizaPreco(String placa , double novopreco) throws PlacaValidacaoExeception, NullExeception, PrecoExeception, VeiculoAlugadoExeception {
		if(placa != null && placa != "") {
			if(novopreco > 0) {
				if( ValidarPlaca(placa) == 0) {
					if(veiculo.Procurar(placa).isStatus() == true) {
						veiculo.Procurar(placa).setPreco(novopreco);
							}else {
								throw new VeiculoAlugadoExeception();
							}
				}else {
					throw new PlacaValidacaoExeception(placa);
				}
			}else {
				throw new PrecoExeception(novopreco);
			}
		}else {
			throw new NullExeception();
		}
	}
	public void AtualizaCor(String placa , String cor) throws PlacaValidacaoExeception, NullExeception {
		if(placa != null && placa != "") {
			if( ValidarPlaca(placa) == 0) {
                     veiculo.Procurar(placa).setCor(cor);
			}else {
				throw new PlacaValidacaoExeception(placa);
			}
		}else {
			throw new NullExeception();
		}

	}
	public void AtualizaKM(String placa , int novaKM) throws PlacaValidacaoExeception, NullExeception, KMExeception {
		if(placa != null && placa != "") {
			if( ValidarPlaca(placa) == 0) {
               if(veiculo.Procurar(placa).getKilometragem() < novaKM) {
            	   veiculo.Procurar(placa).setKilometragem(novaKM);
               }else {
            	   throw new KMExeception(novaKM);
               }		
			}else {
				throw new PlacaValidacaoExeception(placa);
			}
		}else {
			throw new NullExeception();
		}
	}
	public void AtualizarStatus(String placa ) {
        if(veiculo.Procurar(placa).isStatus() == true) {
        	veiculo.Procurar(placa).setStatus(false);
        }else {
        	veiculo.Procurar(placa).setStatus(true);
        }
	}

	public Veiculo Procura(String placa) {
		if(placa != null && placa != "") {
			if(ValidarPlaca(placa) != 0) {	
				return this.veiculo.Procurar(placa);		
			}
		}
		return null;
	}

}