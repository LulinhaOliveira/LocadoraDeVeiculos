package Dados;

import Negocio.Entidades.Veiculo;

public interface IRepositorioVeiculos {
  public void Inserir(Veiculo veiculo);
  public void Remover(String placa);
  public Veiculo Procurar(String placa);
  public Veiculo[] getVeiculo();
  public void salvarArquivo();
  
}
