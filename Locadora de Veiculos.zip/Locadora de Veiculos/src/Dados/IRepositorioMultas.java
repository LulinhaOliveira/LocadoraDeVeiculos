package Dados;

import Negocio.Entidades.Multas;

public interface IRepositorioMultas {
  public void InserirMulta(Multas multa , int indice);
  public void RemoverMulta(int indice);
  public Multas ProcurarMulta(String cpf);
  public Multas[] getMultas();
  public void salvarArquivo();

}
