package Dados;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import Negocio.Entidades.Funcionario;

@SuppressWarnings("serial")
public class FuncionariosRepositorio implements IRepositorioFuncionario, Serializable {
	private Funcionario[] funcionario = new Funcionario[100];

	private static FuncionariosRepositorio instance;

	public static IRepositorioFuncionario getInstance() {
		if (instance == null) {
			instance = lerDoArquivo();
		}
		return instance;
	}

	public static FuncionariosRepositorio lerDoArquivo() {
		FuncionariosRepositorio instanciaLocal = null;
		ObjectInputStream ois = null;
		try {
			Path path = Paths.get("./funcionarios.dat");
			if(!Files.exists(path)) {
				throw new IOException();
			}
			ois = new ObjectInputStream(Files.newInputStream(path));
			instanciaLocal = (FuncionariosRepositorio) ois.readObject();
		} catch (Exception e) {
			instanciaLocal = new FuncionariosRepositorio();
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
				}
			}
		}

		return instanciaLocal;
	}

	public void salvarArquivo() {
		if (instance == null) {
			return;
		}
		ObjectOutputStream oos = null;
		try {
			Path path = Paths.get("./funcionarios.dat");
			if(!Files.isDirectory(path.getParent())) {
				Files.createDirectory(path.getParent());
			}
			if(!Files.exists(path)) {
				Files.createFile(path);
			}
			oos = new ObjectOutputStream(Files.newOutputStream(path));
			oos.writeObject(instance);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
				}
			}
		}
	}

	public Funcionario[] getFuncionario() {
		return funcionario;
	}

	public void setFuncionario(Funcionario[] funcionario) {
		this.funcionario = funcionario;
	}

	public void inserirFuncionario(Funcionario funcionario) {
		for(int i = 0; i < this.funcionario.length; i++) {
			if(this.funcionario[i] == null) {
				this.funcionario[i] = funcionario;
				return;
			} else {
				
			}
		}
	}

	public void removerFuncionario(String cpf) {
		for(int i = 0; i < this.funcionario.length; i++) {
			if(this.funcionario[i].getCpf().equals(cpf)) {
				this.funcionario[i] = null;
			}
		}
	}

	public Funcionario buscarFuncionario(String cpf) {
		for(int i = 0; i < this.funcionario.length; i++) {
			if(this.funcionario[i] == null) {
				continue;
			}
			if(this.funcionario[i].getCpf().equals(cpf)) {
				return funcionario[i];
			}
		}
		return null;
	}

}
