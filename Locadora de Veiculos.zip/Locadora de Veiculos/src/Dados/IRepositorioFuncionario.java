package Dados;

import Negocio.Entidades.Funcionario;


public interface IRepositorioFuncionario {
	
	public void inserirFuncionario(Funcionario funcionario);
	public void removerFuncionario(String cpf);
	public Funcionario buscarFuncionario(String cpf);
	public Funcionario[] getFuncionario();
	public void salvarArquivo();
	
}
