package Dados;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import Negocio.Entidades.Multas;

public class MultasRepositorio implements IRepositorioMultas, Serializable {
private Multas [] multas = new Multas[100];
	
	private static MultasRepositorio instance;
	public static IRepositorioMultas getInstance() {
		if (instance == null) {
			instance = lerDoArquivo();
		}
		return instance;
	}
	public static MultasRepositorio lerDoArquivo() {
		MultasRepositorio instanciaLocal = null;
		ObjectInputStream ois = null;
		try {
			Path path = Paths.get("./multas.dat");
			if(!Files.exists(path)) {
				throw new IOException();
			}
			ois = new ObjectInputStream(Files.newInputStream(path));
			instanciaLocal = (MultasRepositorio) ois.readObject();
		} catch (Exception e) {
			instanciaLocal = new MultasRepositorio();
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
				}
			}
		}

		return instanciaLocal;
	}
	
	public void salvarArquivo() {
		if (instance == null) {
			return;
		}
		ObjectOutputStream oos = null;
		try {
			Path path = Paths.get("./multas.dat");
			if(!Files.isDirectory(path.getParent())) {
				Files.createDirectory(path.getParent());
			}
			if(!Files.exists(path)) {
				Files.createFile(path);
			}
			oos = new ObjectOutputStream(Files.newOutputStream(path));
			oos.writeObject(instance);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
				}
			}
		}
	}
	public Multas[] getMultas() {
		return multas;
	}

	public void setMultas(Multas[] multas) {
		this.multas = multas;
	}

	public void InserirMulta(Multas multa, int indice) {
		this.multas[indice] = multa;
		salvarArquivo();
	}
	public void RemoverMulta(int indice) {
		this.multas[indice] = null;
		
	}
	public Multas ProcurarMulta(String cpf) {
		for(int i = 0; i < this.multas.length; i++) {
			if(this.multas[i] == null) {
				continue;
			}
			if(this.multas[i].getCpfCliente().equals(cpf)) {
				return this.multas[i];
			} 
		}
		return null;
	}
}
