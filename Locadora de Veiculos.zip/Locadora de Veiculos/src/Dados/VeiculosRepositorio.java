package Dados;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import Negocio.Entidades.Veiculo;

public class VeiculosRepositorio implements IRepositorioVeiculos, Serializable {
	private Veiculo [] veiculo = new Veiculo[100];

	private static VeiculosRepositorio instance;
	
	public static IRepositorioVeiculos getInstance() {
		if (instance == null) {
			instance = lerDoArquivo();
		}
		return instance;
	}
	public static VeiculosRepositorio lerDoArquivo() {
		VeiculosRepositorio instanciaLocal = null;
		ObjectInputStream ois = null;
		try {
			Path path = Paths.get("./locacoes.dat");
			if(!Files.exists(path)) {
				throw new IOException();
			}
			ois = new ObjectInputStream(Files.newInputStream(path));
			instanciaLocal = (VeiculosRepositorio) ois.readObject();
		} catch (Exception e) {
			instanciaLocal = new VeiculosRepositorio();
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
				}
			}
		}

		return instanciaLocal;
	}

	public void salvarArquivo() {
		if (instance == null) {
			return;
		}
		ObjectOutputStream oos = null;
		try {
			Path path = Paths.get("./veiculos.dat");
			if(!Files.isDirectory(path.getParent())) {
				Files.createDirectory(path.getParent());
			}
			if(!Files.exists(path)) {
				Files.createFile(path);
			}
			oos = new ObjectOutputStream(Files.newOutputStream(path));
			oos.writeObject(instance);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
				}
			}
		}
	}   

	public Veiculo[] getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(Veiculo[] veiculo) {
		this.veiculo = veiculo;
	}

	public  void Inserir(Veiculo veiculo) {
		for(int i = 0 ; i < this.veiculo.length ; i++) {
			if(this.veiculo[i] == null) {
				this.veiculo[i] = veiculo;
			}
		}
		salvarArquivo();
	}
	public void Remover(String placa) {
		for(int i = 0 ; i < veiculo.length ; i++) {
			if(veiculo[i] == null) {
				continue;
			}
			if(veiculo[i].getPlaca().equals(placa)) {
				veiculo[i] = null;
			}
		}
	}

	public Veiculo Procurar(String placa) {
		for(int i = 0 ; i < this.veiculo.length ; i++) {
			if(this.veiculo[i] == null) {
				continue;
			}
			if(placa.equals(this.veiculo[i].getPlaca())) {
				return  veiculo[i];  
			}
		}
		return  null;           
	}

}