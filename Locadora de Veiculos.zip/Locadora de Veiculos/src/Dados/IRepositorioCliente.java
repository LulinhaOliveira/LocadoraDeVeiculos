package Dados;

import Negocio.Entidades.Cliente;

public interface IRepositorioCliente {
	
	public void inserirCliente(Cliente cliente);
	public void removerCliente(String cpf);
	public Cliente buscarCliente(String cpf);
	public void atualizarCliente(String cpf);
	public void salvarArquivo();
	public Cliente[] getCliente();

}
