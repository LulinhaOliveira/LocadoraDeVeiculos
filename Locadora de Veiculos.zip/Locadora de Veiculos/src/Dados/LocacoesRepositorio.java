package Dados;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import Negocio.Entidades.Locacao;


public class LocacoesRepositorio implements IRepositorioLocacoes, Serializable{
	private Locacao [] locacoes = new Locacao[100];
	
	private static LocacoesRepositorio instance;
	
	public static IRepositorioLocacoes getInstance() {
		if (instance == null) {
			instance = lerDoArquivo();
		}
		return instance;
	}
	public static LocacoesRepositorio lerDoArquivo() {
		LocacoesRepositorio instanciaLocal = null;
		ObjectInputStream ois = null;
		try {
			Path path = Paths.get("./locacoes.dat");
			if(!Files.exists(path)) {
				throw new IOException();
			}
			ois = new ObjectInputStream(Files.newInputStream(path));
			instanciaLocal = (LocacoesRepositorio) ois.readObject();
		} catch (Exception e) {
			instanciaLocal = new LocacoesRepositorio();
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
				}
			}
		}

		return instanciaLocal;
	}
	
	public void salvarArquivo() {
		if (instance == null) {
			return;
		}
		ObjectOutputStream oos = null;
		try {
			Path path = Paths.get("./locacoes.dat");
			if(!Files.isDirectory(path.getParent())) {
				Files.createDirectory(path.getParent());
			}
			if(!Files.exists(path)) {
				Files.createFile(path);
			}
			oos = new ObjectOutputStream(Files.newOutputStream(path));
			oos.writeObject(instance);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
				}
			}
		}
	}
	
	public void inserirLocacao(Locacao locacao) {
		for(int i = 0; i < locacoes.length; i++) {
			if(this.locacoes[i] == null) {
				this.locacoes[i] = locacao;
				salvarArquivo();
			} 
		}
	}

	public void removerLocacao(String cpf) {
		for(int i = 0; i < locacoes.length; i++) {
			if(this.locacoes[i].getClienteCPF().equals(cpf)) {
				this.locacoes[i] = null;
			}
		}
	}

	public Locacao buscarLocacao(String cpf) {
		for(int i = 0; i < locacoes.length; i++) {
			if(this.locacoes[i] == null) {
				continue;
			}
			if(this.locacoes[i].getClienteCPF().equals(cpf)) {
				return this.locacoes[i];
			}
		}
		return null;
	}

	public Locacao [] getLocacao() {
		return locacoes;
	}

	public void setLocacao(Locacao [] locacao) {
		this.locacoes = locacao;
	}
}


