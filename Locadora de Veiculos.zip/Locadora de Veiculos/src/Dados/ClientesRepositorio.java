package Dados;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import Negocio.Entidades.Cliente;


@SuppressWarnings("serial")
public class ClientesRepositorio implements IRepositorioCliente, Serializable{

	private Cliente[] cliente = new Cliente[100];

	private static ClientesRepositorio instance;

	public static IRepositorioCliente getInstance() {
		if (instance == null) {
			instance = lerDoArquivo();
		}
		return instance;
	}
	
	public static ClientesRepositorio lerDoArquivo() {
		ClientesRepositorio instanciaLocal = null;
		ObjectInputStream ois = null;
		try {
			Path path = Paths.get("./clientes.dat");
			if(!Files.exists(path)) {
				throw new IOException();
			}
			ois = new ObjectInputStream(Files.newInputStream(path));
			instanciaLocal = (ClientesRepositorio) ois.readObject();
		} catch (Exception e) {
			instanciaLocal = new ClientesRepositorio();
		} finally {
			if (ois != null) {
				try {
					ois.close();
				} catch (IOException e) {
				}
			}
		}

		return instanciaLocal;
	}

	public void salvarArquivo() {
		if (instance == null) {
			return;
		}
		ObjectOutputStream oos = null;
		try {
			Path path = Paths.get("./clientes.dat");
			if(!Files.isDirectory(path.getParent())) {
				Files.createDirectory(path.getParent());
			}
			if(!Files.exists(path)) {
				Files.createFile(path);
			}
			oos = new ObjectOutputStream(Files.newOutputStream(path));
			oos.writeObject(instance);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (oos != null) {
				try {
					oos.close();
				} catch (IOException e) {
				}
			}
		}
	}

	public Cliente[] getCliente() {
		return cliente;
	}

	public void setCliente(Cliente[] cliente) {
		this.cliente = cliente;
	}

	public void inserirCliente(Cliente cliente) {
		for(int i = 0; i < this.cliente.length; i++) {
			if(this.cliente[i] == null) {
				this.cliente[i] = cliente;
				return;
			} else {
				
			}
		}
		salvarArquivo();
	}

	public void removerCliente(String cpf) {
		for(int i = 0; i < this.cliente.length; i++) {
			if(this.cliente[i].getCpf().equals(cpf)) {
				this.cliente[i] = null;
			}
		}
	}

	public Cliente buscarCliente(String cpf) {
		for(int i = 0; i < this.cliente.length; i++) {
			if(this.cliente[i] == null) {
				continue;
			}
			if(this.cliente[i].getCpf().equals(cpf)) {
				return cliente[i];
			} 
		}
		return null;
	}

	public void atualizarCliente(String cpf) {
		for(int i = 0; i < this.cliente.length; i++) {
			if(this.cliente[i].getCpf().equals(cpf)) {
				if(this.cliente[i].getStatus() == "Ativo") {
					this.cliente[i].setStatus("Desativado");
				} else {
					this.cliente[i].setStatus("Ativo");
				}
			}
		}
	}
}
