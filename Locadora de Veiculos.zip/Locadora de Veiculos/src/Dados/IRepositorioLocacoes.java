package Dados;

import Negocio.Entidades.Locacao;

public interface IRepositorioLocacoes {
  public void inserirLocacao(Locacao locacao);
  public void removerLocacao(String cpf);
  public Locacao buscarLocacao(String cpf);
  public Locacao [] getLocacao();
  public void salvarArquivo();
}
