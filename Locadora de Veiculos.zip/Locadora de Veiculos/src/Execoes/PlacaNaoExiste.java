package Execoes;

@SuppressWarnings("serial")
public class PlacaNaoExiste extends Exception {
	public String toString() {
		return "Placa N�o Existe";
	}
}
