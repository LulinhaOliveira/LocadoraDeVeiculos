package Execoes;

@SuppressWarnings("serial")
public class PrecoExeception  extends Exception{
	private double preco;

	public PrecoExeception(double preco){
		this.setPreco(preco);
	}
	@Override
	public String toString() {
		return " Pre�o Deve Ser Maior Que Zero";
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		this.preco = preco;
	}


}
