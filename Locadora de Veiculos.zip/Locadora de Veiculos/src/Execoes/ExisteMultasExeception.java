package Execoes;

@SuppressWarnings("serial")
public class ExisteMultasExeception extends Exception {
public String toString() {
	return "Existe Multas a Serem Pagas";
}
}
