package Execoes;

@SuppressWarnings("serial")
public class KMExeception extends Exception {
	private int km;
	public KMExeception(int km){
		this.setKm(km);
	}
	public int getKm() {
		return km;
	}

	public void setKm(int km) {
		this.km = km;
	}
	@Override
	public String toString() {
		return "Quilometragem Atual Deve Ser Maior qu a Anterior";
	}
}
