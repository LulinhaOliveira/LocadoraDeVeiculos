package Execoes;

@SuppressWarnings("serial")
public class ItensLocadosCheio extends Exception {
	public String toString() {
		return "Quantidade Itens Locados ao Maximo";
	}
}
