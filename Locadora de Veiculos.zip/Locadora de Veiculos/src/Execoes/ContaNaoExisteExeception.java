package Execoes;

@SuppressWarnings("serial")
public class ContaNaoExisteExeception extends Exception{
	public String toString() {
		return "Usuario ou Senha Incorreto";
	}
}
