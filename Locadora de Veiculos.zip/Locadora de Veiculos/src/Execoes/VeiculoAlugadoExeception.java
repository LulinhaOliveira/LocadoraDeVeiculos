package Execoes;

@SuppressWarnings("serial")
public class VeiculoAlugadoExeception extends Exception {

public String toString() {
	return "Veiculo J� Alugado";
}
}
