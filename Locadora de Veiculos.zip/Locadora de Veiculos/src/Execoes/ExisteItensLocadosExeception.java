package Execoes;

@SuppressWarnings("serial")
public class ExisteItensLocadosExeception extends Exception {
	public String toString() {
		return "Existem Itens Locados";
	}
}
