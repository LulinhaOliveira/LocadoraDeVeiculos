package Execoes;

@SuppressWarnings("serial")
public class CpfException extends Exception {
	String cpf;
	
	public CpfException(String cpf) {
		this.cpf = cpf;
	}
	
	public String ToString() {
		return "CPF inv�lido, digite novamente";
	}
}
