package Execoes;

@SuppressWarnings("serial")
public class NullExeception extends Exception {


	public String toString() {
		return "N�o Segue os Requisitos";
	}

}
